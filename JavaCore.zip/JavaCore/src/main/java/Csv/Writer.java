package Csv;

public class Writer {
    public Writer(String s) {
    }

    public Practic5.Writer delimiter(char c) {
    }
}
