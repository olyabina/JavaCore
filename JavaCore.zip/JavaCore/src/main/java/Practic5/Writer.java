package Practic5;

import javax.xml.bind.annotation.XmlElementRefs;

public class Writer {
    public XmlElementRefs comment(String example_of_csv) {
    }
}
