package Practic5;

import java.io.FileReader;

public class Reader {
    public Reader(FileReader filename) {
    }

    public boolean readLine() {
    }

    public Object delimiter(char c) {
    }
}
